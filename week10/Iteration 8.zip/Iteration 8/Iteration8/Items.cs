﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iteration8
{
    public class Item(string[] idents, string name, string desc) : GameObject(idents, name, desc)
    {

    }
}
